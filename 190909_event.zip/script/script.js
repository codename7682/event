$(document).ready(function(){
    
    $("p").dblclick(function(){
        $(this).hide();
    });
    // p태그가 눌렸을때 그것을(그p태그) 숨겨라
    
    $("#motive").keyup(function(){
        var letter = $(this).val().length;
        $("#count>span").text(letter);
        if(letter > 10){
            alert("10자 이내로 작성하시오.");
        }
    });
    
    // #motive의 내용이 바뀌었을때
        // (그것) 안에 있는 내용(value)을 알아내서
        // 그 내용의 글자 수(length)를 알아내서
        // #count>span에다가 글자수를 내용으로 쓴다.
        // 그런데 만약 글자수가 10개 초과되면
            // 그땐 경고창을 띄운다.
    
    $("#motive").focus(function(){
        $(this).css("background-color","yellow");
    });
    $("#motive").blur(function(){
        $(this).css("background-color","white");
    });
    
    // #motive에 focus가 들어오면
        // 그것의 배경색을 노란색으로 바꾼다.
    // #motive에 blur가 되면
        // 그것의 배경색을 흰색으로 바꾼다.
    
    $(document).mousemove(function(event){
        var mx = event.pageX;
        var my = event.pageY;
        $("#coord").text(mx+","+my);
    });
    // 문서 내에서 마우스가 움직일 때마다
        // 방금움직인 그 이벤트에서 마우스의 좌표를
        // 알아내서
        // #coord에다가 그 값을 써준다.
    
    
    
    $(".main").mouseover(function(){
        $(this).children(".sub").stop().fadeIn();
    });
    $(".main").mouseout(function(){
        $(this).children(".sub").stop().fadeOut();
    });
    
    // .main에 마우스를 올렸을때
        // [마우스를올린 그것]의 자식 .sub를 서서히 보여준다.
    // .main에서 마우스를 치웠을때
        // [마우스를치운 그것]의 자식 .sub를 서서히 숨겨준다.

    chkscr();
    
    var sw;
    var sh;
    
    function chkscr(){
        sw = $(window).width();
        sh = $(window).height();
        $("#swidth").text(sw + "px");
        $("#sheight").text(sh + "px");
    }
    
    $(window).resize(function(){
        chkscr();
        if(sw >= 600){
            $("nav").show();
        }else{
            $("nav").hide();
        }
    });
    
    // 화면 크기가 바뀔때
        // 화면의 가로길이가 600이상이면
            // nav를 보여준다.
        // 그렇지 않으면 (화면의 가로길이가 600미만일때)
            // nav를 숨겨준다.
    
    
    
});







